let fruta = ["laranja", "maça", "kiwi"]

fruta.push("morango")
alert (fruta)